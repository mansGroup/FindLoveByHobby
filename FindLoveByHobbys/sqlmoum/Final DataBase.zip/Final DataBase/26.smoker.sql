--------------------------------------------------------
--  파일이 생성됨 - 금요일-8월-18-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table SMOKER
--------------------------------------------------------

  CREATE TABLE "SKOTT"."SMOKER" 
   (	"SMOKER_ID" VARCHAR2(20 BYTE), 
	"SMOKER_NAME" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into SKOTT.SMOKER
SET DEFINE OFF;
Insert into SKOTT.SMOKER (SMOKER_ID,SMOKER_NAME) values ('1','흡연');
Insert into SKOTT.SMOKER (SMOKER_ID,SMOKER_NAME) values ('2','비흡연');
--------------------------------------------------------
--  DDL for Index SMOKER_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SKOTT"."SMOKER_PK" ON "SKOTT"."SMOKER" ("SMOKER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Trigger SMOKER_TRG
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "SKOTT"."SMOKER_TRG" 
BEFORE INSERT ON SMOKER 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;

/
ALTER TRIGGER "SKOTT"."SMOKER_TRG" ENABLE;
--------------------------------------------------------
--  Constraints for Table SMOKER
--------------------------------------------------------

  ALTER TABLE "SKOTT"."SMOKER" MODIFY ("SMOKER_ID" NOT NULL ENABLE);
  ALTER TABLE "SKOTT"."SMOKER" ADD CONSTRAINT "SMOKER_PK" PRIMARY KEY ("SMOKER_ID")
  USING INDEX "SKOTT"."SMOKER_PK"  ENABLE;
