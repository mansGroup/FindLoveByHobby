--------------------------------------------------------
--  파일이 생성됨 - 금요일-8월-18-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table DRINGS
--------------------------------------------------------

  CREATE TABLE "SKOTT"."DRINGS" 
   (	"DRINGS_ID" VARCHAR2(20 BYTE), 
	"DRINGS_NAME" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into SKOTT.DRINGS
SET DEFINE OFF;
Insert into SKOTT.DRINGS (DRINGS_ID,DRINGS_NAME) values ('1','마시지 않음');
Insert into SKOTT.DRINGS (DRINGS_ID,DRINGS_NAME) values ('2','가끔 마심');
Insert into SKOTT.DRINGS (DRINGS_ID,DRINGS_NAME) values ('3','자주 마심');
--------------------------------------------------------
--  DDL for Index DRINGS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SKOTT"."DRINGS_PK" ON "SKOTT"."DRINGS" ("DRINGS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Trigger DRINGS_TRG
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "SKOTT"."DRINGS_TRG" 
BEFORE INSERT ON DRINGS 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/
ALTER TRIGGER "SKOTT"."DRINGS_TRG" ENABLE;
--------------------------------------------------------
--  DDL for Trigger DRINGS_TRG1
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "SKOTT"."DRINGS_TRG1" 
BEFORE INSERT ON DRINGS 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    IF INSERTING AND :NEW.DRINGS_ID IS NULL THEN
      SELECT DRINGS_SEQ.NEXTVAL INTO :NEW.DRINGS_ID FROM SYS.DUAL;
    END IF;
  END COLUMN_SEQUENCES;
END;
/
ALTER TRIGGER "SKOTT"."DRINGS_TRG1" ENABLE;
--------------------------------------------------------
--  Constraints for Table DRINGS
--------------------------------------------------------

  ALTER TABLE "SKOTT"."DRINGS" MODIFY ("DRINGS_ID" NOT NULL ENABLE);
  ALTER TABLE "SKOTT"."DRINGS" ADD CONSTRAINT "DRINGS_PK" PRIMARY KEY ("DRINGS_ID")
  USING INDEX "SKOTT"."DRINGS_PK"  ENABLE;
